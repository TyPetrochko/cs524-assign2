make task1; make task2; make task3
